<?php

/*
  This file is part of ADIOS Framework.

  This file is published under the terms of the license described
  in the license.md file which is located in the root folder of
  ADIOS Framework package.
*/

namespace ADIOS\Core\ViewsWithController\Inputs;

class ManyToMany extends \ADIOS\Core\ViewsWithController\Input {

  public function render(string $panel = ''): string
  {
    $model = $this->app->getModel($this->params['model']);
    
    switch ($this->params['columns'] ?? 3) {
      case 1: default: $bootstrapColumnSize = 12; break;
      case 2: $bootstrapColumnSize = 6; break;
      case 3: $bootstrapColumnSize = 4; break;
      case 4: $bootstrapColumnSize = 3; break;
      case 6: $bootstrapColumnSize = 2; break;
    }
    
    $columns = $model->columns();

    if (empty($this->params['model']) || !is_array($columns)) {
      throw new \ADIOS\Core\Exceptions\GeneralException("ManyToMany Input: Error #1");
    }

    $srcColumn = $this->params['relation'][0];
    $dstColumn = $this->params['relation'][1];

    $srcModel = $this->app->getModel($columns[$srcColumn]['model']);
    $dstModel = $this->app->getModel($columns[$dstColumn]['model']);

    $dstItems = $this->app->db->fetchRaw("
      select
        `dst`.`id`,
        ".$dstModel->lookupSqlValue('dst')." as `lookup_sql_value`
      from `".$dstModel->getFullTableSqlName()."` dst
      order by ".($this->params['order'] ?? "id asc")."
    ");

    $valuesRaw = $this->app->db->fetchRaw("
      select
        *
      from `".$model->getFullTableSqlName()."`
      where
        ".(empty($this->params['constraints'][$srcColumn]) ? "TRUE" : "`{$srcColumn}` = {$this->params['constraints'][$srcColumn]}")."
        and ".(empty($this->params['constraints'][$dstColumn]) ? "TRUE" : "`{$dstColumn}` = {$this->params['constraints'][$dstColumn]}")."
    ");
    $values = [];
    foreach ($valuesRaw as $valueRaw) {
      $values[] = $valueRaw[$dstColumn];
    }
    $values = array_unique($values);
    
    $html = "
      <div class='adios ui Input checkbox-field'>
        <input type='hidden' id='{$this->uid}' data-is-adios-input='1'>
        <div class='row'>
    ";
    foreach ($dstItems as $item) {
      $html .= "
        <div class='col-lg-{$bootstrapColumnSize} col-md-12'>
          <input
            type='checkbox'
            data-id='{$item['id']}'
            adios-do-not-serialize='1'
            id='{$this->uid}_checkbox_{$item['id']}'
            onchange='{$this->uid}_serialize();'
            ".(in_array($item['id'], $values) ? "checked" : "")."
          >
          <label for='{$this->uid}_checkbox_{$item['id']}'>
            ".hsc($item['lookup_sql_value'])."
          </label>
        </div>
      ";
    }
    $html .= "
        </div>
      </div>
      <script>
        function {$this->uid}_serialize() {
          let data = [];
          $('#{$this->uid}').closest('.checkbox-field').find('input[type=checkbox]:checked').each(function() {
            data.push($(this).data('id'));
          });
          $('#{$this->uid}').val(JSON.stringify(data));
        }

        {$this->uid}_serialize();
      </script>
    ";


    return $html;
  }
}
